<?php

use App\Http\Controllers\cus_sup\loginController;
use App\Http\Controllers\cus_sup\regesterController;
use App\Http\Controllers\user;
use App\Http\Controllers\user\login;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\user\regester;



use App\Http\Controllers\serviseProvi\login as sevLogin;
use App\Http\Controllers\serviseProvi\regester as sevRegester;
use App\Http\Controllers\user\servesesconttroler;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::post('login',[login::class ,'login']);
Route::post('register',[regester::class ,'register']);



Route::group(['prefix' => 'user', 'middleware' => 'auth:sanctum'], function () {
    Route::prefix('user')->group(function () {
      
        Route::post('logout',[login::class ,'logout']);
        Route::post('verify','user\VerifyController@verify');
        Route::post('resend_verification_code','user\VerifyController@resend');
    
        Route::prefix('password')->group(function () {
            Route::post('forget','user\ResetPasswordController@sendCode');
            Route::post('check','user\ResetPasswordController@check');
            Route::post('reset','user\ResetPasswordController@resetPassword');
        });

        Route::get('Home',[servesesconttroler::class ,'servioses']);

    
    });
});





// Route::middleware('auth:api')->get('/userApth', function (Request $request) {
//     return $request->user();
// });


  
    
    // Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    //     return $request->user();
    // });



Route::prefix('service_provider')->group(function () {
    Route::post('register',[sevRegester::class ,'register']);
    Route::post('login',[sevLogin::class ,'login']);


    Route::post('verify','user\VerifyController@verify');
    Route::post('resend_verification_code','user\VerifyController@resend');

    Route::prefix('password')->group(function () {
        Route::post('forget','user\ResetPasswordController@sendCode');
        Route::post('check','user\ResetPasswordController@check');
        Route::post('reset','user\ResetPasswordController@resetPassword');
    });

});






Route::prefix('customer_support')->group(function () {
    Route::post('register',[regesterController::class ,'register']);
    Route::post('login',[loginController::class ,'login']);
    Route::post('verify','user\VerifyController@verify');
    Route::post('resend_verification_code','user\VerifyController@resend');

    Route::prefix('password')->group(function () {
        Route::post('forget','user\ResetPasswordController@sendCode');
        Route::post('check','user\ResetPasswordController@check');
        Route::post('reset','user\ResetPasswordController@resetPassword');
    });

});