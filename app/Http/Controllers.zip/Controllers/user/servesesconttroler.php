<?php

namespace App\Http\Controllers\user;
// use App\Models\servise_porvider\user_servic ;
use App\Models\userCus\Users as User;

use App\Http\Controllers\Controller;
use App\Http\Controllers\cus_sup\resetpassController;
use App\Http\Resources\Ponts_serv;
use App\Http\Resources\reprts;
use App\Models\pymentation;
use App\Models\report;
// use App\Models\servise_porvider\user_servic as User;

use App\Models\servise_porvider\user_servic;
use App\Models\type_service_has;
use App\Models\userCus\servesesconttroler as UserCusServesesconttroler;
use Illuminate\Http\Request;

use function PHPSTORM_META\type;

class servesesconttroler extends Controller
{
    public function servioses(Request $request)
    {
       $Emergency=UserCusServesesconttroler::select('id', 'name' ,'type')->where('type','=','Emergency')->get();
       $Maintenance=UserCusServesesconttroler::select('id', 'name' ,'type')->where('type','=','Maintenance')->get();
       $AnotherService=UserCusServesesconttroler::select('id', 'name' ,'type')->where('type','=','Another Service')->get();
       $location=user_servic::select('centerName', 'location' )->get();
    //    $users = DB::table('sevices')->select('id','name', 'type')->get();
    return response()->json([
        'Emergency' =>    $Emergency   ,
        'Maintenance' =>    $Maintenance  ,
        'AnotherService' =>  $AnotherService    ,
        'location' =>  $location    ,
        
        
        ]
    );
    

   
    }

    public function usergetserv($type)
    {
        $typeServise =$type;
        
        // $AnotherService=user_servic::with('orders')->get();
        $AnotherService=type_service_has::where('type' , '=' ,$typeServise)->with('user')->get();

        return response()->json([

            'Service  avelb' =>  $AnotherService  ,
          
            
            
            ]
        );

    }
    public function user_nedservice(Request $request)
    {
  
       $iduser = $request->idUser;
       $idservics = $request->ID_services_providers;
       $report = $request->report;
     
    //    $iduser_=report::where('id' , '=' ,$iduser)->first();
    //    $d_users = intval($iduser_->id_User);
       $phone=User::where('id' , '=' ,$iduser)->first();

            $add=   report::create([
            
                'id_User' => $iduser,
                'id_sirvice' => $idservics,
                'text_' => $report,
                'phone' => $phone->phone,
                'prise' => $request->prise,
            
            ]);


        if (!$add) {

            $sat='no';
            return response()->json([

                'stat' =>     $sat  ,
                
                ]
            );

        }else {
            $sat='yes';
        return response()->json([

            'stat' =>     $sat  ,
            
            ]
        );
        
        }


    }

    public function carent_req($id)
    {


     $AnotherService=report::where('id_User' , '=' ,$id)->where('stat' , '=' ,1)->where('pymentstate' ,'=' ,0)->where('pyments_user' ,'=' ,0)->get();


        return response()->json([

            'carent_req' =>  reprts::collection( $AnotherService)   ,
          
            
            
            ]
        );

    }
    

    public function service_provider_Phone($id)
    {


     $AnotherService=user_servic::select('phone')->where('id' , '=' ,$id)->get();


        return response()->json([

            'service_provider_Phone' =>    $AnotherService   ,
          
            
            
            ]
        );

    }
    

    public function check_get($id)
    {
        // $typeServise =$id;
        
        // $AnotherService=user_servic::with('orders')->get();
        // $AnotherService=type_service_has::where('type' , 'like' ,$typeServise)->with('user')->get();
        $AnotherService=report::where('id_User' , '=' ,$id)->where('stat' , '=' ,1)->where('pymentstate' ,'=' ,1)->where('pyments_user' ,'=' ,0)->get();


        return response()->json([

            'Basket' =>    reprts::collection(  $AnotherService )  ,
          
            
            
            ]
        );

    }


    public function chek_aot(Request $request)
    {
       $id=$request->id;

        $AnotherService=report::where('id_User' , '=' ,$id)->where('stat' , '=' ,1)->where('pymentstate' ,'=' ,1)->where('pyments_user' ,'=' ,0)->sum('prise');
        // return $AnotherService;

        $prise_on_acc =    pymentation::where('id_user', '=', $id)->first();
        $mo =   intval(@$prise_on_acc ->money );
        if ($AnotherService > @$mo) {

         return 'Your current balance is not allowed';
        }elseif ($AnotherService < $mo) {
         $new_mo = $mo - $AnotherService;
        

         pymentation::where('id_user', $id) ->update([
        'money' => $new_mo
         ]);


        return "ok";
        }
    
    }



}
