<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Http\Controllers\cus_sup\resetpassController;
use App\Models\servise_porvider\user_servic;
use App\Models\userCus\servesesconttroler as UserCusServesesconttroler;
use Illuminate\Http\Request;

class servesesconttroler extends Controller
{
    public function servioses(Request $request)
    {
       $Emergency=UserCusServesesconttroler::select('id', 'name' ,'type')->where('type','=','Emergency')->get();
       $Maintenance=UserCusServesesconttroler::select('id', 'name' ,'type')->where('type','=','Maintenance')->get();
       $AnotherService=UserCusServesesconttroler::select('id', 'name' ,'type')->where('type','=','Another Service')->get();
       $location=user_servic::select('centerName', 'location' )->get();
    //    $users = DB::table('sevices')->select('id','name', 'type')->get();
    return response()->json([
        'Emergency' =>    $Emergency   ,
        'Maintenance' =>    $Maintenance  ,
        'AnotherService' =>  $AnotherService    ,
        'location' =>  $location    ,
        
        
        ]
    );
    
    
   ;
    }
}
